class place {
}