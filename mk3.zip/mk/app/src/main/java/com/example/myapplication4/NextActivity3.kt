
package com.example.myapplication4

// NextActivity3.kt
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.naver.maps.geometry.LatLng
import com.naver.maps.map.CameraUpdate
import com.naver.maps.map.MapFragment
import com.naver.maps.map.NaverMap
import com.naver.maps.map.OnMapReadyCallback
import com.naver.maps.map.overlay.Marker


class NextActivity3 : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var naverMap: NaverMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_next3)



        // 지도 초기화
        val fm = supportFragmentManager
        val mapFragment = fm.findFragmentById(R.id.map_fragment) as MapFragment?
            ?: MapFragment.newInstance().also {
                fm.beginTransaction().add(R.id.map_fragment, it).commit()
            }
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(naverMap: NaverMap) {
        this.naverMap = naverMap

        // Intent로 전달된 좌표 목록 가져오기
        val coordinates = intent.getParcelableArrayListExtra<LatLng>("coordinates") ?: return

        // 각 좌표에 마커 추가
        coordinates.forEach { coordinate ->
            Marker().apply {
                position = coordinate
                map = naverMap
            }
        }

        // 첫 번째 좌표로 카메라 이동
        if (coordinates.isNotEmpty()) {
            val cameraUpdate = CameraUpdate.scrollTo(coordinates[0])
            naverMap.moveCamera(cameraUpdate)
        }
    }
}
