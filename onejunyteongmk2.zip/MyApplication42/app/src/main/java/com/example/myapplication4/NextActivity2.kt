package com.example.myapplication4

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

data class Place(
    val name: String,
    val rating: Double,
    val reviews: String,
    val imageResId: Int? = null,
    val url: String? = null // URL 필드 추가
)

class Category(val categoryName: String) {
    private val places = mutableListOf<Place>()
    fun addPlace(place: Place) = places.add(place)
    fun getRandomPlace(): Place? = if (places.isNotEmpty()) places.random() else null
}

class NextActivity2 : AppCompatActivity() {

    private lateinit var restaurantCategory: Category
    private lateinit var cafeCategory: Category
    private lateinit var lodgingCategory: Category
    private lateinit var dateSpotCategory: Category

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_next2)

        initializeCategories()

        val selectedCategories = intent.getStringArrayListExtra("selectedCategories") ?: arrayListOf()

        selectedCategories.forEach { category ->
            when (category) {
                "음식점" -> setupCategoryUI(
                    restaurantCategory,
                    R.id.restaurantTextView,
                    R.id.restaurantImageView,
                    R.id.restaurantRerollButton,
                    R.id.restaurantUrlTextView
                )
                "카페" -> setupCategoryUI(
                    cafeCategory,
                    R.id.cafeTextView,
                    R.id.cafeImageView,
                    R.id.cafeRerollButton,
                    R.id.cafeUrlTextView
                )
                "숙박" -> setupCategoryUI(
                    lodgingCategory,
                    R.id.lodgingTextView,
                    R.id.lodgingImageView,
                    R.id.lodgingRerollButton,
                    R.id.lodgingUrlTextView
                )
                "데이트 명소" -> setupCategoryUI(
                    dateSpotCategory,
                    R.id.dateSpotTextView,
                    R.id.dateSpotImageView,
                    R.id.dateSpotRerollButton,
                    R.id.dateSpotUrlTextView
                )
            }
        }
    }

    private fun initializeCategories() {
        restaurantCategory = Category("음식점").apply {

            addPlace(Place("권돼지국밥", 4.54, "614개", R.drawable.r1, "https://naver.me/FCAw2v1d"))
            addPlace(Place("오사장횟집", 4.27, "84개", R.drawable.r2, "https://naver.me/xQegc1RG"))
            addPlace(Place("은성게장더크랩", 4.41, "200개", R.drawable.r3, "https://naver.me/FQVFJdpo"))
            addPlace(Place("콩세상웰빙솥밥", 4.41, "352개", R.drawable.r4, "https://naver.me/G7VXtdEH"))
            addPlace(Place("샐러든", 4.56, "369개", R.drawable.r5, "https://naver.me/FgHx74o0"))
            addPlace(Place("경성식육식당", 4.52, "404개", R.drawable.r6, "https://naver.me/FG7k5Rq9"))
            addPlace(Place("맛이좋은집", 4.41, "565개", R.drawable.r7, "https://naver.me/FEUGE6rM"))
            addPlace(Place("삼성패밀리뷔페", 4.16, "373개", R.drawable.r8, "https://naver.me/G4WEcsXy"))
            addPlace(Place("카시강", 4.57, "235개", R.drawable.r9, "https://naver.me/GNWlTj4d"))
            addPlace(Place("소우주", 4.7, "109개", R.drawable.r10, "https://naver.me/Galw3sva"))
            addPlace(Place("대봉식당", 4.78, "110개", R.drawable.r11, "https://naver.me/5ISajor4"))
            addPlace(Place("쿄우라멘", 4.55, "298개", R.drawable.r12, "https://naver.me/GFBrJjnX"))
            addPlace(Place("남가람청국장마을", 4.35, "195개", R.drawable.r13, "https://naver.me/xrSWR0Yg"))
            addPlace(Place("망경횟집", 4.2, "229개", R.drawable.r14, "https://naver.me/GtUuX755"))
            addPlace(Place("재경장어", 4.69, "308개", R.drawable.r15, "https://naver.me/Fr7OwpYn"))
            addPlace(Place("라쿵푸마라탕", 4.38, "530개", R.drawable.r16, "https://naver.me/5EUymBF5"))
            addPlace(Place("상하이객잔", 4.6, "117개", R.drawable.r17, "https://naver.me/5chse7dQ"))
            addPlace(Place("진주국밥 본점", 4.44, "176개", R.drawable.r18, "https://naver.me/GTnbBJeE"))
            addPlace(Place("회초랑", 4.33, "46개", R.drawable.r19, "https://naver.me/xmx4MWqf"))
            addPlace(Place("고구려", 4.54, "1,831개", R.drawable.r20, "https://naver.me/x5GBEToF"))
            addPlace(Place("현대옥", 4.3, "277개", R.drawable.r21, "https://naver.me/5Rh51z66"))
            addPlace(Place("비금", 4.49, "223개", R.drawable.r22, "https://naver.me/xRh8YSOu"))
            addPlace(Place("1440수제돈까스", 4.54, "191개", R.drawable.r23, "https://naver.me/FlZGjXeu"))
            addPlace(Place("진성식당", 4.13, "103개", R.drawable.r24, "https://naver.me/GDayhlkM"))
            addPlace(Place("소문난반성장터국밥", 4.44, "113개", R.drawable.r25, "https://naver.me/5UEMkukl"))
            addPlace(Place("백조품은오리", 4.63, "342개", R.drawable.r26, "https://naver.me/GRopVV7W"))
            addPlace(Place("대복갈비살", 4.65, "103개", R.drawable.r27, "https://naver.me/GKU49Czy"))
            addPlace(Place("소우리", 4.4, "484개", R.drawable.r28, "https://naver.me/GOP3lLyC"))
            addPlace(Place("엄마국수", 4.42, "189개", R.drawable.r29, "https://naver.me/5MV2knti"))
            addPlace(Place("명샤브", 4.56, "357개", R.drawable.r30, "https://naver.me/5HkWz3sz"))























        }
        cafeCategory = Category("카페").apply {
            addPlace(Place("스타벅스", 4.0, "150개", R.drawable.p3, "https://naver.me/Gsjm1FJG"))
            addPlace(Place("투썸플레이스", 3.8, "90개", R.drawable.p4, "https://naver.me/xbw9WHuS"))
        }
        lodgingCategory = Category("숙박").apply {
            addPlace(Place("신라호텔", 4.8, "200개 이상", R.drawable.p5, "https://naver.me/xbw9WHuS"))
            addPlace(Place("롯데호텔", 4.5, "180개", R.drawable.p6, "https://naver.me/xbw9WHuS"))
        }
        dateSpotCategory = Category("데이트 명소").apply {
            addPlace(Place("남산타워", 4.7, "500개 이상", R.drawable.r1, "https://naver.me/xbw9WHuS"))
            addPlace(Place("한강공원", 4.3, "350개", R.drawable.r2, "https://naver.me/xbw9WHuS"))




















        }
    }

    private fun setupCategoryUI(
        category: Category,
        textViewId: Int,
        imageViewId: Int,
        rerollButtonId: Int,
        urlTextViewId: Int
    ) {
        displayRandomPlace(category, textViewId, imageViewId, urlTextViewId)

        findViewById<Button>(rerollButtonId).apply {
            visibility = View.VISIBLE
            setOnClickListener {
                displayRandomPlace(category, textViewId, imageViewId, urlTextViewId)
            }
        }
    }

    private fun displayRandomPlace(category: Category, textViewId: Int, imageViewId: Int, urlTextViewId: Int) {
        val place = category.getRandomPlace()
        place?.let { selectedPlace ->
            findViewById<TextView>(textViewId).apply {
                text = "이름: ${selectedPlace.name}\n별점: ${selectedPlace.rating}\n리뷰: ${selectedPlace.reviews}"
                visibility = View.VISIBLE
            }
            findViewById<ImageView>(imageViewId).apply {
                setImageResource(selectedPlace.imageResId ?: R.drawable.r1)
                visibility = View.VISIBLE
            }
            findViewById<TextView>(urlTextViewId).apply {
                text = "지도로 보기"
                visibility = View.VISIBLE
                setOnClickListener { openUrl(selectedPlace.url) }
            }
        }
    }

    private fun openUrl(url: String?) {
        url?.let {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(it))
            startActivity(intent)
        }
    }
}
