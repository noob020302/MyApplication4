package com.example.myapplication4

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

data class Place(
    val name: String,
    val rating: Double,
    val reviews: String,
    val imageResId: Int? = null,
    val url: String? = null // URL 필드 추가
)

class Category(val categoryName: String) {
    private val places = mutableListOf<Place>()
    fun addPlace(place: Place) = places.add(place)
    fun getRandomPlace(): Place? = if (places.isNotEmpty()) places.random() else null
}

class NextActivity2 : AppCompatActivity() {

    private lateinit var restaurantCategory: Category
    private lateinit var cafeCategory: Category
    private lateinit var lodgingCategory: Category
    private lateinit var dateSpotCategory: Category

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_next2)

        initializeCategories()

        val selectedCategories = intent.getStringArrayListExtra("selectedCategories") ?: arrayListOf()

        selectedCategories.forEach { category ->
            when (category) {
                "음식점" -> setupCategoryUI(
                    restaurantCategory,
                    R.id.restaurantTextView,
                    R.id.restaurantImageView,
                    R.id.restaurantRerollButton,
                    R.id.restaurantUrlTextView
                )
                "카페" -> setupCategoryUI(
                    cafeCategory,
                    R.id.cafeTextView,
                    R.id.cafeImageView,
                    R.id.cafeRerollButton,
                    R.id.cafeUrlTextView
                )
                "숙박" -> setupCategoryUI(
                    lodgingCategory,
                    R.id.lodgingTextView,
                    R.id.lodgingImageView,
                    R.id.lodgingRerollButton,
                    R.id.lodgingUrlTextView
                )
                "데이트 명소" -> setupCategoryUI(
                    dateSpotCategory,
                    R.id.dateSpotTextView,
                    R.id.dateSpotImageView,
                    R.id.dateSpotRerollButton,
                    R.id.dateSpotUrlTextView
                )
            }
        }
    }

    private fun initializeCategories() {
        restaurantCategory = Category("음식점").apply {
            addPlace(Place("백첩식당", 3.5, "100개", R.drawable.p1, "https://naver.me/xMjATgDh"))
            addPlace(Place("장충동 왕족발", 4.5, "300개 이상", R.drawable.p2, "https://naver.me/5N1z2Wd0"))
        }
        cafeCategory = Category("카페").apply {
            addPlace(Place("스타벅스", 4.0, "150개", R.drawable.p3, "https://naver.me/Gsjm1FJG"))
            addPlace(Place("투썸플레이스", 3.8, "90개", R.drawable.p4, "https://naver.me/xbw9WHuS"))
        }
        lodgingCategory = Category("숙박").apply {
            addPlace(Place("신라호텔", 4.8, "200개 이상", R.drawable.p5, "https://naver.me/xbw9WHuS"))
            addPlace(Place("롯데호텔", 4.5, "180개", R.drawable.p6, "https://naver.me/xbw9WHuS"))
        }
        dateSpotCategory = Category("데이트 명소").apply {
            addPlace(Place("남산타워", 4.7, "500개 이상", R.drawable.p1, "https://naver.me/xbw9WHuS"))
            addPlace(Place("한강공원", 4.3, "350개", R.drawable.p2, "https://naver.me/xbw9WHuS"))
        }
    }

    private fun setupCategoryUI(
        category: Category,
        textViewId: Int,
        imageViewId: Int,
        rerollButtonId: Int,
        urlTextViewId: Int
    ) {
        displayRandomPlace(category, textViewId, imageViewId, urlTextViewId)

        findViewById<Button>(rerollButtonId).apply {
            visibility = View.VISIBLE
            setOnClickListener {
                displayRandomPlace(category, textViewId, imageViewId, urlTextViewId)
            }
        }
    }

    private fun displayRandomPlace(category: Category, textViewId: Int, imageViewId: Int, urlTextViewId: Int) {
        val place = category.getRandomPlace()
        place?.let { selectedPlace ->
            findViewById<TextView>(textViewId).apply {
                text = "이름: ${selectedPlace.name}\n별점: ${selectedPlace.rating}\n리뷰: ${selectedPlace.reviews}"
                visibility = View.VISIBLE
            }
            findViewById<ImageView>(imageViewId).apply {
                setImageResource(selectedPlace.imageResId ?: R.drawable.p1)
                visibility = View.VISIBLE
            }
            findViewById<TextView>(urlTextViewId).apply {
                text = "지도로 보기"
                visibility = View.VISIBLE
                setOnClickListener { openUrl(selectedPlace.url) }
            }
        }
    }

    private fun openUrl(url: String?) {
        url?.let {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(it))
            startActivity(intent)
        }
    }
}
